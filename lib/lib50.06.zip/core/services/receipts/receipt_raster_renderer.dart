import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:qr_flutter/qr_flutter.dart';

import 'package:holol_POS/core/services/invoices/invoice_document.dart';
import 'package:holol_POS/core/services/invoices/receipt_template_labels.dart';
import 'package:holol_POS/core/services/receipts/receipt_render_profile.dart';

class ReceiptRasterImage {
  final int widthPx;
  final int heightPx;
  final int paperWidthMm;
  final Uint8List pngBytes;
  final Uint8List rgbaBytes;

  const ReceiptRasterImage({
    required this.widthPx,
    required this.heightPx,
    required this.paperWidthMm,
    required this.pngBytes,
    required this.rgbaBytes,
  });
}

/// Single visual source of truth for POS receipts.
class ReceiptRasterRenderer {
  static const String _defaultSideLogoAsset =
      'assets/images/receipt_powered_by.png';

  final ReceiptTemplateLabels labels;
  final String sideLogoAsset;
  final String sideBrandName;
  final String sideBrandPhone;
  final String sideBrandWebsite;

  const ReceiptRasterRenderer({
    this.labels = const ReceiptTemplateLabels.ar(),
    this.sideLogoAsset = _defaultSideLogoAsset,
    this.sideBrandName = 'نظام hololErp المحاسبي السحابي',
    this.sideBrandPhone = '966565561972',
    this.sideBrandWebsite = 'hololerp.com',
  });

  Future<ReceiptRasterImage> renderImage(
    InvoiceDocument document, {
    int? paperWidthMm,
    ReceiptRenderProfile? profile,
  }) async {
    final effectiveProfile =
        profile ??
        ReceiptRenderProfile.thermal(paperWidthMm: paperWidthMm ?? 80);
    final sideLogo = await _loadImageAsset(sideLogoAsset);

    final painter = _ReceiptPainter(
      document: document,
      labels: labels,
      profile: effectiveProfile,
      sideLogo: sideLogo,
      sideBrandName: sideBrandName,
      sideBrandPhone: sideBrandPhone,
      sideBrandWebsite: sideBrandWebsite,
    );

    final heightPx = painter.measureHeightPx();

    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder)
      ..drawRect(
        Rect.fromLTWH(
          0,
          0,
          effectiveProfile.widthPx.toDouble(),
          heightPx.toDouble(),
        ),
        Paint()..color = Colors.white,
      );

    painter.paint(canvas);

    final image = await recorder.endRecording().toImage(
      effectiveProfile.widthPx,
      heightPx,
    );

    final pngBytes = await image.toByteData(format: ui.ImageByteFormat.png);
    final rgbaBytes = await image.toByteData(
      format: ui.ImageByteFormat.rawRgba,
    );

    if (pngBytes == null || rgbaBytes == null) {
      throw StateError('Unable to render receipt image.');
    }

    return ReceiptRasterImage(
      widthPx: effectiveProfile.widthPx,
      heightPx: image.height,
      paperWidthMm: effectiveProfile.paperWidthMm,
      pngBytes: _copyBytes(pngBytes),
      rgbaBytes: _copyBytes(rgbaBytes),
    );
  }

  Future<Uint8List> renderPng(
    InvoiceDocument document, {
    int? paperWidthMm,
    ReceiptRenderProfile? profile,
  }) async {
    return (await renderImage(
      document,
      paperWidthMm: paperWidthMm,
      profile: profile,
    )).pngBytes;
  }

  Future<List<int>> renderEscPosRaster(
    InvoiceDocument document, {
    int? paperWidthMm,
    ReceiptRenderProfile? profile,
  }) async {
    final effectiveProfile =
        profile ??
        ReceiptRenderProfile.thermal(paperWidthMm: paperWidthMm ?? 80);
    final image = await renderImage(document, profile: effectiveProfile);
    return _encodeRasterBands(image, effectiveProfile);
  }

  static Future<ui.Image?> _loadImageAsset(String assetPath) async {
    try {
      final data = await rootBundle.load(assetPath);
      final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
      final frame = await codec.getNextFrame();
      return frame.image;
    } catch (_) {
      return null;
    }
  }

  static Uint8List _copyBytes(ByteData data) {
    return Uint8List.fromList(
      data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
    );
  }

  List<int> _encodeRasterBands(
    ReceiptRasterImage image,
    ReceiptRenderProfile profile,
  ) {
    final widthBytes = (image.widthPx + 7) ~/ 8;
    final output = <int>[];
    for (var y0 = 0; y0 < image.heightPx; y0 += profile.rasterBandHeight) {
      final h = (image.heightPx - y0) < profile.rasterBandHeight
          ? (image.heightPx - y0)
          : profile.rasterBandHeight;

      final data = Uint8List(widthBytes * h);

      for (var y = 0; y < h; y++) {
        final sourceY = y0 + y;

        for (var x = 0; x < image.widthPx; x++) {
          final offset = (sourceY * image.widthPx + x) * 4;
          final r = image.rgbaBytes[offset];
          final g = image.rgbaBytes[offset + 1];
          final b = image.rgbaBytes[offset + 2];

          final luminance = (r * 0.299 + g * 0.587 + b * 0.114).round();

          if (luminance < profile.rasterThreshold) {
            data[y * widthBytes + (x ~/ 8)] |= 0x80 >> (x % 8);
          }
        }
      }

      output.addAll([
        0x1D,
        0x76,
        0x30,
        0x00,
        widthBytes & 0xFF,
        (widthBytes >> 8) & 0xFF,
        h & 0xFF,
        (h >> 8) & 0xFF,
        ...data,
        0x0A,
      ]);
    }

    return output;
  }
}

class _ReceiptPainter {
  final InvoiceDocument document;
  final ReceiptTemplateLabels labels;
  final ReceiptRenderProfile profile;
  final ui.Image? sideLogo;
  final String sideBrandName;
  final String sideBrandPhone;
  final String sideBrandWebsite;

  final _ReceiptText text = const _ReceiptText();

  _ReceiptPainter({
    required this.document,
    required this.labels,
    required this.profile,
    required this.sideLogo,
    required this.sideBrandName,
    required this.sideBrandPhone,
    required this.sideBrandWebsite,
  });

  double get _sideRailWidth => profile.paperWidthMm <= 58 ? 18 : 24;

  double get width => profile.widthPx.toDouble();

  double get contentLeft => profile.leftMargin + _sideRailWidth;

  double get contentRight => width - profile.rightMargin;

  double get contentWidth => contentRight - contentLeft;

  int measureHeightPx() {
    final measured = _layout(null) + profile.margin;
    return measured.ceil().clamp(560, 30000).toInt();
  }

  void paint(Canvas canvas) {
    _layout(canvas);
  }

  double _layout(Canvas? canvas) {
    final startY = profile.margin;
    var y = startY;

    y = _storeHeader(canvas, y);
    y = _receiptTitle(canvas, y + 5);
    y = _meta(canvas, y + 5);
    y = _customer(canvas, y + 4);
    y = _items(canvas, y + 6);
    y = _totals(canvas, y + 6);
    y = _taxSummary(canvas, y + 4);
    y = _payments(canvas, y + 6);
    y = _qr(canvas, y + 7);
    y = _footer(canvas, y + 5);

    if (canvas != null) {
      _sideBrand(canvas, startY, y);
    }

    return y;
  }

  double _storeHeader(Canvas? canvas, double y) {
    final lines = <_HeaderLine>[
      _HeaderLine(
        document.seller.name,
        size: profile.titleFont,
        bold: true,
        maxLines: 2,
      ),
    ];

    final address = _firstVisible([
      document.branch.address,
      document.branch.city,
      document.seller.address,
    ]);

    if (_visible(address)) {
      lines.add(
        _HeaderLine(': $address', size: profile.smallFont, maxLines: 2),
        //_HeaderLine('العنوان: $address', size: profile.smallFont, maxLines: 2),
      );
    }

    if (_visible(document.seller.phone)) {
      lines.add(
        _HeaderLine(
          'الهاتف: ${document.seller.phone}',
          size: profile.smallFont,
          maxLines: 1,
        ),
      );
    }

    final taxNo = _firstVisible([
      document.seller.taxNumber,
      document.branch.taxNumber,
    ]);

    if (_visible(taxNo)) {
      lines.add(
        _HeaderLine(
          '${labels.taxNumber}: $taxNo',
          size: profile.smallFont,
          bold: true,
          maxLines: 1,
        ),
      );
    }

    final cr = _firstVisible([
      document.seller.commercialRegistration,
      document.branch.commercialRegistration,
    ]);

    if (_visible(cr)) {
      lines.add(
        _HeaderLine('السجل التجاري: $cr', size: profile.smallFont, maxLines: 1),
      );
    }

    return _headerCard(canvas, y, lines);
  }

  double _headerCard(Canvas? canvas, double y, List<_HeaderLine> lines) {
    const horizontalPadding = 7.0;
    const verticalPadding = 6.0;
    const lineGap = 1.0;

    var contentH = 0.0;

    for (final line in lines) {
      contentH += text.measure(
        line.value,
        width: contentWidth - (horizontalPadding * 2),
        size: line.size,
        bold: line.bold,
        align: TextAlign.center,
        dir: line.dir,
        maxLines: line.maxLines,
      );
      contentH += lineGap;
    }

    if (contentH > 0) contentH -= lineGap;

    final boxH = contentH + (verticalPadding * 2);
    final rect = Rect.fromLTWH(contentLeft, y, contentWidth, boxH);

    if (canvas != null) {
      _roundBox(canvas, rect, radius: 8, strokeWidth: 0.85);

      var lineY = y + verticalPadding;

      for (final line in lines) {
        final lineH = text.measure(
          line.value,
          width: contentWidth - (horizontalPadding * 2),
          size: line.size,
          bold: line.bold,
          align: TextAlign.center,
          dir: line.dir,
          maxLines: line.maxLines,
        );

        text.draw(
          canvas,
          line.value,
          Rect.fromLTWH(
            contentLeft + horizontalPadding,
            lineY,
            contentWidth - (horizontalPadding * 2),
            lineH,
          ),
          size: line.size,
          bold: line.bold,
          align: TextAlign.center,
          dir: line.dir,
          maxLines: line.maxLines,
        );

        lineY += lineH + lineGap;
      }
    }

    return y + boxH;
  }

  double _receiptTitle(Canvas? canvas, double y) {
    final title = document.copyInfo.isCopy
        ? '${labels.simplifiedTaxInvoice} - ${document.copyInfo.label}'
        : labels.simplifiedTaxInvoice;

    final h =
        text.measure(
          title,
          width: contentWidth - 14,
          size: profile.font,
          bold: true,
          align: TextAlign.center,
          maxLines: 2,
        ) +
        10;

    final rect = Rect.fromLTWH(contentLeft, y, contentWidth, h);

    if (canvas != null) {
      _roundBox(canvas, rect, radius: 7, strokeWidth: 1.0);

      text.draw(
        canvas,
        title,
        rect.deflate(6),
        size: profile.font,
        bold: true,
        align: TextAlign.center,
        maxLines: 2,
      );
    }

    return y + h;
  }

  double _meta(Canvas? canvas, double y) {
    return _keyValueTable(canvas, y, [
      _KeyValue('رقم الفاتورة', document.localInvoiceNo, TextDirection.ltr),
      _KeyValue(
        labels.date,
        '${_date(document.invoiceDateTime)} ${_time(document.invoiceDateTime)}',
        TextDirection.ltr,
      ),
      _KeyValue(labels.cashier, document.cashier.name, TextDirection.rtl),
      _KeyValue(
        labels.terminal,
        document.terminal.terminalId,
        TextDirection.ltr,
      ),
    ], compact: true);
  }

  double _customer(Canvas? canvas, double y) {
    final rows = <_KeyValue>[];

    if (document.customer?.name.trim().isNotEmpty == true) {
      rows.add(
        _KeyValue(labels.customer, document.customer!.name, TextDirection.rtl),
      );
    }

    if (document.customer?.taxNumber?.trim().isNotEmpty == true) {
      rows.add(
        _KeyValue(
          labels.taxNumber,
          document.customer!.taxNumber!,
          TextDirection.ltr,
        ),
      );
    }

    if (rows.isEmpty) return y - 4;

    return _keyValueTable(canvas, y, rows, compact: true);
  }

  double _items(Canvas? canvas, double y) {
    final columns = _itemColumns();

    final rows = <_TableRow>[
      _TableRow.header([
        'الصنف',
        'الوحدة',
        'السعر',
        'كمية',
        'خصم',
        'ضريبة',
        'الإجمالي',
      ]),
      ...document.lines.map((line) {
        return _TableRow.body([
          line.itemName.trim(),
          _visible(line.unitName) ? line.unitName!.trim() : '-',
          text.amount(line.display.unitPrice),
          line.display.quantity,
          line.discountAmount > 0
              ? text.amount(line.display.discountAmount)
              : '0',
          line.taxAmount > 0 ? text.amount(line.display.taxAmount) : '0',
          text.money(line.display.lineTotal),
        ]);
      }),
    ];

    return _gridTable(
      canvas,
      y,
      columns: columns,
      rows: rows,
      fontSize: profile.paperWidthMm <= 58 ? 7.8 : 10.0,
      headerFontSize: profile.paperWidthMm <= 58 ? 7.3 : 9.4,
      padY: profile.paperWidthMm <= 58 ? 2.0 : 2.8,
      radius: 6,
    );
  }

  List<_TableColumn> _itemColumns() {
    final ratios = profile.paperWidthMm <= 58
        ? <double>[0.27, 0.10, 0.12, 0.08, 0.10, 0.11, 0.22]
        : <double>[0.30, 0.10, 0.12, 0.08, 0.10, 0.11, 0.19];

    return [
      _TableColumn(
        ratio: ratios[0],
        align: TextAlign.right,
        dir: TextDirection.rtl,
        maxLines: 2,
      ),
      _TableColumn(
        ratio: ratios[1],
        align: TextAlign.center,
        dir: TextDirection.rtl,
      ),
      _TableColumn(
        ratio: ratios[2],
        align: TextAlign.center,
        dir: TextDirection.ltr,
      ),
      _TableColumn(
        ratio: ratios[3],
        align: TextAlign.center,
        dir: TextDirection.ltr,
      ),
      _TableColumn(
        ratio: ratios[4],
        align: TextAlign.center,
        dir: TextDirection.ltr,
      ),
      _TableColumn(
        ratio: ratios[5],
        align: TextAlign.center,
        dir: TextDirection.ltr,
      ),
      _TableColumn(
        ratio: ratios[6],
        align: TextAlign.center,
        dir: TextDirection.ltr,
        bold: true,
      ),
    ];
  }

  double _totals(Canvas? canvas, double y) {
    final t = document.totals;

    return _keyValueTable(canvas, y, [
      _KeyValue(
        'الإجمالي شامل الضريبة',
        text.money(t.displayNetTotal),
        TextDirection.ltr,
      ),
      _KeyValue(
        'مجموع الخصومات',
        text.money(t.displayDiscountTotal),
        TextDirection.ltr,
      ),
      _KeyValue(
        'المجموع قبل الضريبة',
        text.money(t.displaySubtotal),
        TextDirection.ltr,
      ),
      _KeyValue(
        'مجموع ضريبة القيمة المضافة',
        text.money(t.displayTaxTotal),
        TextDirection.ltr,
      ),
      _KeyValue(
        'الإجمالي',
        text.money(t.displayNetTotal),
        TextDirection.ltr,
        bold: true,
      ),
      _KeyValue(
        'المبلغ المدفوع',
        text.money(t.displayPaidTotal),
        TextDirection.ltr,
      ),
      _KeyValue(
        'المبلغ المتبقي',
        text.money(t.displayRemainingTotal),
        TextDirection.ltr,
        bold: t.remainingTotal > 0,
      ),
      if (t.changeAmount > 0)
        _KeyValue(
          labels.change,
          text.money(t.displayChangeAmount),
          TextDirection.ltr,
          bold: true,
        ),
    ]);
  }

  double _taxSummary(Canvas? canvas, double y) {
    if (document.taxSummary.length <= 1) return y - 4;

    return _keyValueTable(
      canvas,
      y,
      document.taxSummary.map((tax) {
        return _KeyValue(
          '${labels.tax} ${tax.displayRate}',
          '${text.money(tax.displayTaxableAmount)} / ${text.money(tax.displayTaxAmount)}',
          TextDirection.ltr,
        );
      }).toList(),
    );
  }

  double _payments(Canvas? canvas, double y) {
    final hasPayments = document.payments.isNotEmpty;
    final hasRemaining = document.totals.remainingTotal > 0;

    if (!hasPayments && !hasRemaining) return y - 6;

    final rows = <_KeyValue>[];

    if (!hasPayments && hasRemaining) {
      rows.add(
        const _KeyValue('طريقة الدفع', 'آجل', TextDirection.rtl, bold: true),
      );
      rows.add(
        _KeyValue(
          'المبلغ المتبقي',
          text.money(document.totals.displayRemainingTotal),
          TextDirection.ltr,
          bold: true,
        ),
      );
    } else {
      for (final payment in document.payments) {
        rows.add(
          _KeyValue(
            'طريقة الدفع',
            _paymentMethodLabel(payment),
            TextDirection.rtl,
            bold: true,
          ),
        );

        rows.add(
          _KeyValue(
            'المبلغ',
            text.money(payment.displayAmount),
            TextDirection.ltr,
          ),
        );

        if (_visible(payment.referenceNo)) {
          rows.add(
            _KeyValue(
              labels.reference,
              payment.referenceNo!,
              TextDirection.ltr,
            ),
          );
        }
      }
    }

    return _keyValueTable(canvas, y, rows);
  }

  double _gridTable(
    Canvas? canvas,
    double y, {
    required List<_TableColumn> columns,
    required List<_TableRow> rows,
    required double fontSize,
    required double headerFontSize,
    required double padY,
    required double radius,
  }) {
    final widths = columns
        .map((column) => contentWidth * column.ratio)
        .toList();

    final heights = rows.map((row) {
      final size = row.header ? headerFontSize : fontSize;
      return _tableRowHeight(
        row,
        columns: columns,
        widths: widths,
        fontSize: size,
        padY: padY,
      );
    }).toList();

    final tableH = heights.fold<double>(0, (sum, h) => sum + h);

    if (canvas != null) {
      final rect = Rect.fromLTWH(contentLeft, y, contentWidth, tableH);
      final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius));

      final gridPaint = Paint()
        ..color = Colors.black
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.4;

      final outerPaint = Paint()
        ..color = Colors.black
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.75;

      var rowY = y;

      for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) {
        final row = rows[rowIndex];
        final rowH = heights[rowIndex];
        final size = row.header ? headerFontSize : fontSize;

        _paintTableRow(
          canvas,
          rowY,
          rowH,
          row,
          columns: columns,
          widths: widths,
          fontSize: size,
        );

        rowY += rowH;

        if (rowIndex < rows.length - 1) {
          canvas.drawLine(
            Offset(contentLeft, rowY),
            Offset(contentRight, rowY),
            gridPaint,
          );
        }
      }

      var x = contentRight;

      for (var i = 0; i < widths.length - 1; i++) {
        x -= widths[i];

        canvas.drawLine(Offset(x, y), Offset(x, y + tableH), gridPaint);
      }

      canvas.drawRRect(rrect, outerPaint);
    }

    return y + tableH;
  }

  double _tableRowHeight(
    _TableRow row, {
    required List<_TableColumn> columns,
    required List<double> widths,
    required double fontSize,
    required double padY,
  }) {
    var h = 0.0;

    for (var i = 0; i < row.cells.length; i++) {
      final column = columns[i];

      final cellH = text.measure(
        row.cells[i],
        width: widths[i] - 4,
        size: fontSize,
        bold: row.header || column.bold,
        align: column.align,
        dir: column.dir,
        maxLines: column.maxLines,
      );

      if (cellH > h) h = cellH;
    }

    return h + (padY * 2);
  }

  void _paintTableRow(
    Canvas canvas,
    double y,
    double h,
    _TableRow row, {
    required List<_TableColumn> columns,
    required List<double> widths,
    required double fontSize,
  }) {
    var right = contentRight;

    for (var i = 0; i < row.cells.length; i++) {
      final column = columns[i];
      final w = widths[i];
      final rect = Rect.fromLTWH(right - w, y, w, h).deflate(2);

      text.draw(
        canvas,
        row.cells[i],
        rect,
        size: fontSize,
        bold: row.header || column.bold,
        align: column.align,
        dir: column.dir,
        maxLines: column.maxLines,
      );

      right -= w;
    }
  }

  double _keyValueTable(
    Canvas? canvas,
    double y,
    List<_KeyValue> rows, {
    bool compact = false,
  }) {
    if (rows.isEmpty) return y;

    final valueW = contentWidth * 0.34;
    final labelW = contentWidth - valueW;
    final pad = compact ? 2.5 : 3.4;

    final heights = rows.map((row) {
      final size = row.bold ? profile.font : profile.smallFont;

      final labelH = text.measure(
        row.label,
        width: labelW - 8,
        size: size,
        bold: row.bold,
        align: TextAlign.right,
        dir: TextDirection.rtl,
        maxLines: null,
      );

      final valueH = text.measure(
        row.value,
        width: valueW - 8,
        size: size,
        bold: row.bold,
        align: TextAlign.right,
        dir: row.valueDirection,
        maxLines: null,
      );

      return _max(labelH, valueH) + (pad * 2);
    }).toList();

    final tableH = heights.fold<double>(0, (sum, h) => sum + h);

    if (canvas != null) {
      final rect = Rect.fromLTWH(contentLeft, y, contentWidth, tableH);
      final rrect = RRect.fromRectAndRadius(rect, const Radius.circular(6));

      final gridPaint = Paint()
        ..color = Colors.black
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.4;

      final outerPaint = Paint()
        ..color = Colors.black
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.75;

      final dividerX = contentLeft + valueW;

      canvas.drawLine(
        Offset(dividerX, y),
        Offset(dividerX, y + tableH),
        gridPaint,
      );

      var rowY = y;

      for (var i = 0; i < rows.length; i++) {
        final row = rows[i];
        final h = heights[i];
        final size = row.bold ? profile.font : profile.smallFont;

        final valueRect = Rect.fromLTWH(
          contentLeft,
          rowY,
          valueW,
          h,
        ).deflate(4);
        final labelRect = Rect.fromLTWH(dividerX, rowY, labelW, h).deflate(4);

        text.draw(
          canvas,
          row.label,
          labelRect,
          size: size,
          bold: row.bold,
          align: TextAlign.right,
          dir: TextDirection.rtl,
          maxLines: null,
        );

        text.draw(
          canvas,
          row.value,
          valueRect,
          size: size,
          bold: row.bold,
          align: TextAlign.right,
          dir: row.valueDirection,
          maxLines: null,
        );

        rowY += h;

        if (i < rows.length - 1) {
          canvas.drawLine(
            Offset(contentLeft, rowY),
            Offset(contentRight, rowY),
            gridPaint,
          );
        }
      }

      canvas.drawRRect(rrect, outerPaint);
    }

    return y + tableH;
  }

  String _paymentMethodLabel(InvoicePaymentDocument payment) {
    final raw = [
      payment.paymentMethodCode,
      payment.methodName,
      payment.displayMethod,
    ].where((value) => value.trim().isNotEmpty).join(' ').toLowerCase();

    if (raw.contains('cash') || raw.contains('نقد') || raw.contains('صندوق')) {
      return 'كاش';
    }

    if (raw.contains('mada') ||
        raw.contains('مدى') ||
        raw.contains('card') ||
        raw.contains('visa') ||
        raw.contains('master') ||
        raw.contains('network') ||
        raw.contains('شبكة') ||
        raw.contains('بطاقة')) {
      return 'شبكة';
    }

    if (raw.contains('credit') ||
        raw.contains('deferred') ||
        raw.contains('postpaid') ||
        raw.contains('آجل') ||
        raw.contains('اجل')) {
      return 'آجل';
    }

    if (payment.displayMethod.trim().isNotEmpty) {
      return payment.displayMethod.trim();
    }

    if (payment.methodName.trim().isNotEmpty) {
      return payment.methodName.trim();
    }

    return 'كاش';
  }

  double _qr(Canvas? canvas, double y) {
    final payload = document.qrPayload?.trim();

    if (payload == null || payload.isEmpty) return y - 7;

    final qrSize = profile.paperWidthMm <= 58 ? 126.0 : 152.0;
    final quietZone = 7.0;
    final left = contentLeft + ((contentWidth - qrSize) / 2);

    if (canvas != null) {
      canvas.drawRect(
        Rect.fromLTWH(
          left - quietZone,
          y,
          qrSize + quietZone * 2,
          qrSize + quietZone * 2,
        ),
        Paint()..color = Colors.white,
      );

      final painter = QrPainter(
        data: payload,
        version: QrVersions.auto,
        gapless: true,
        eyeStyle: const QrEyeStyle(
          eyeShape: QrEyeShape.square,
          color: Colors.black,
        ),
        dataModuleStyle: const QrDataModuleStyle(
          dataModuleShape: QrDataModuleShape.square,
          color: Colors.black,
        ),
      );

      canvas.save();
      canvas.translate(left, y + quietZone);
      painter.paint(canvas, Size(qrSize, qrSize));
      canvas.restore();
    }

    return y + qrSize + (quietZone * 2);
  }

  double _footer(Canvas? canvas, double y) {
    if (_visible(document.notes)) {
      y = _centerText(
        canvas,
        y,
        document.notes!,
        size: profile.smallFont,
        bold: true,
        maxLines: null,
      );
      y += 4;
    }

    final footer = [
      document.localInvoiceNo,
      document.cashier.name,
      document.terminal.terminalId,
    ].where((value) => value.trim().isNotEmpty).join(' • ');

    if (footer.isNotEmpty) {
      y = _centerText(
        canvas,
        y,
        footer,
        size: profile.smallFont,
        bold: true,
        maxLines: 2,
      );
      y += 2;
    }

    return _centerText(
      canvas,
      y,
      'شكراً لتعاملكم معنا',
      size: profile.smallFont,
      bold: true,
      maxLines: 1,
    );
  }

  void _sideBrand(Canvas canvas, double top, double bottom) {
    final railLeft = 2.0;
    final railWidth = _sideRailWidth - 4;
    final available = (bottom - top).clamp(120.0, double.infinity);
    final logoSize = profile.paperWidthMm <= 58 ? 12.0 : 15.0;
    final maxTextWidth = available - logoSize - 8;
    const segmentGap = 4.0;

    final segments = <_SideBrandSegment>[
      const _SideBrandSegment('نظام', TextDirection.rtl, bold: true),
      const _SideBrandSegment('hololErp', TextDirection.ltr, bold: true),
      const _SideBrandSegment(
        'المحاسبي السحابي',
        TextDirection.rtl,
        bold: true,
      ),
      _SideBrandSegment(sideBrandWebsite, TextDirection.ltr),
      _SideBrandSegment(sideBrandPhone, TextDirection.ltr),
    ];

    var fontSize = profile.paperWidthMm <= 58 ? 6.8 : 8.6;
    const minFontSize = 5.2;

    double totalWidthFor(double size) {
      var total = 0.0;

      for (var i = 0; i < segments.length; i++) {
        final painter = _sideTextPainter(segments[i], size: size)..layout();
        total += painter.width;

        if (i < segments.length - 1) {
          total += segmentGap;
        }
      }

      return total;
    }

    while (fontSize > minFontSize && totalWidthFor(fontSize) > maxTextWidth) {
      fontSize -= 0.3;
    }

    final centerY = top + (available / 2);

    canvas.save();
    canvas.translate(railLeft, centerY + (available / 2));
    canvas.rotate(-math.pi / 2);

    if (sideLogo != null) {
      final logoRect = Rect.fromLTWH(0, 1, logoSize, logoSize);
      _drawImageCover(canvas, sideLogo!, logoRect);
    }

    var x = logoSize + 4.0;

    for (final segment in segments) {
      final painter = _sideTextPainter(segment, size: fontSize)..layout();
      final y = 1 + ((railWidth - painter.height) / 2);

      painter.paint(canvas, Offset(x, y));
      x += painter.width + segmentGap;
    }

    canvas.restore();
  }

  TextPainter _sideTextPainter(
    _SideBrandSegment segment, {
    required double size,
  }) {
    return TextPainter(
      text: TextSpan(
        text: segment.text,
        style: TextStyle(
          color: Colors.black,
          fontSize: size,
          fontWeight: segment.bold ? FontWeight.w800 : FontWeight.w600,
          height: 1.0,
          fontFamily: _sideHasArabic(segment.text) ? null : 'monospace',
        ),
      ),
      textDirection: segment.direction,
      textAlign: TextAlign.left,
      maxLines: 1,
      textWidthBasis: TextWidthBasis.longestLine,
    );
  }

  bool _sideHasArabic(String value) {
    return RegExp(r'[\u0600-\u06FF]').hasMatch(value);
  }

  void _drawImageCover(Canvas canvas, ui.Image image, Rect dst) {
    final src = Rect.fromLTWH(
      0,
      0,
      image.width.toDouble(),
      image.height.toDouble(),
    );

    canvas.drawImageRect(image, src, dst, Paint());
  }

  double _centerText(
    Canvas? canvas,
    double y,
    String value, {
    required double size,
    bool bold = false,
    TextDirection dir = TextDirection.rtl,
    int? maxLines = 2,
  }) {
    final h = text.measure(
      value,
      width: contentWidth,
      size: size,
      bold: bold,
      align: TextAlign.center,
      dir: dir,
      maxLines: maxLines,
    );

    if (canvas != null) {
      text.draw(
        canvas,
        value,
        Rect.fromLTWH(contentLeft, y, contentWidth, h),
        size: size,
        bold: bold,
        align: TextAlign.center,
        dir: dir,
        maxLines: maxLines,
      );
    }

    return y + h;
  }

  void _roundBox(
    Canvas canvas,
    Rect rect, {
    double radius = 7,
    double strokeWidth = 1.0,
  }) {
    final rrect = RRect.fromRectAndRadius(rect, Radius.circular(radius));

    canvas.drawRRect(
      rrect,
      Paint()
        ..color = Colors.white
        ..style = PaintingStyle.fill,
    );

    canvas.drawRRect(
      rrect,
      Paint()
        ..color = Colors.black
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth,
    );
  }

  String _date(DateTime value) {
    final local = value.toLocal();
    final year = local.year.toString().padLeft(4, '0');
    final month = local.month.toString().padLeft(2, '0');
    final day = local.day.toString().padLeft(2, '0');
    return '$year/$month/$day';
  }

  String _time(DateTime value) {
    final local = value.toLocal();
    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  String? _firstVisible(List<String?> values) {
    for (final value in values) {
      if (_visible(value)) return value!.trim();
    }

    return null;
  }

  bool _visible(String? value) => value != null && value.trim().isNotEmpty;

  double _max(double a, double b) => a > b ? a : b;
}

class _SideBrandSegment {
  final String text;
  final TextDirection direction;
  final bool bold;

  const _SideBrandSegment(this.text, this.direction, {this.bold = false});
}

class _HeaderLine {
  final String value;
  final double size;
  final bool bold;
  final TextDirection dir;
  final int? maxLines;

  const _HeaderLine(
    this.value, {
    required this.size,
    this.bold = false,
    this.dir = TextDirection.rtl,
    this.maxLines = 1,
  });
}

class _TableColumn {
  final double ratio;
  final TextAlign align;
  final TextDirection dir;
  final int? maxLines;
  final bool bold;

  const _TableColumn({
    required this.ratio,
    required this.align,
    required this.dir,
    this.maxLines = 1,
    this.bold = false,
  });
}

class _TableRow {
  final List<String> cells;
  final bool header;

  const _TableRow._(this.cells, {required this.header});

  factory _TableRow.header(List<String> cells) {
    return _TableRow._(cells, header: true);
  }

  factory _TableRow.body(List<String> cells) {
    return _TableRow._(cells, header: false);
  }
}

class _KeyValue {
  final String label;
  final String value;
  final TextDirection valueDirection;
  final bool bold;

  const _KeyValue(
    this.label,
    this.value,
    this.valueDirection, {
    this.bold = false,
  });
}

class _ReceiptText {
  static const String _riyalSymbol = '\uE900';
  static const String _riyalFontFamily = 'saudi-riyal';

  const _ReceiptText();

  String amount(String value) {
    var clean = value
        .replaceAll('\u2066', '')
        .replaceAll('\u2067', '')
        .replaceAll('\u2068', '')
        .replaceAll('\u2069', '')
        .replaceAll('\u200E', '')
        .replaceAll('\u200F', '')
        .replaceAll(_riyalSymbol, '')
        .replaceAll('ر.س.', '')
        .replaceAll('ر.س', '')
        .replaceAll('SAR', '')
        .replaceAll('sar', '')
        .replaceAll(',', '')
        .trim();

    if (clean.isEmpty) return '0';

    final parsed = double.tryParse(clean);

    if (parsed == null) return clean;

    return parsed == parsed.roundToDouble()
        ? parsed.toInt().toString()
        : parsed.toStringAsFixed(2);
  }

  String money(String value) {
    return '${amount(value)} $_riyalSymbol';
  }

  double measure(
    String value, {
    required double width,
    required double size,
    bool bold = false,
    TextAlign align = TextAlign.right,
    TextDirection dir = TextDirection.rtl,
    int? maxLines = 2,
  }) {
    if (_isSingleMoney(value)) {
      return _measureMoney(value, size: size, bold: bold);
    }

    final painter = _painter(
      value,
      size: size,
      bold: bold,
      align: align,
      dir: dir,
      maxLines: maxLines,
    )..layout(maxWidth: width);

    return painter.height;
  }

  void draw(
    Canvas canvas,
    String value,
    Rect rect, {
    required double size,
    bool bold = false,
    TextAlign align = TextAlign.right,
    TextDirection dir = TextDirection.rtl,
    int? maxLines = 2,
  }) {
    if (_isSingleMoney(value)) {
      _drawMoney(canvas, value, rect, size: size, bold: bold, align: align);
      return;
    }

    final painter = _painter(
      value,
      size: size,
      bold: bold,
      align: align,
      dir: dir,
      maxLines: maxLines,
    )..layout(maxWidth: rect.width);

    final dx = _dxFor(rect, painter.width, align);
    painter.paint(canvas, Offset(dx, rect.top));
  }

  bool _isSingleMoney(String value) {
    final normalized = _stripDirectionMarks(value);

    if (!normalized.contains(_riyalSymbol) &&
        !normalized.contains('ر.س') &&
        !normalized.toUpperCase().contains('SAR')) {
      return false;
    }

    return double.tryParse(amount(normalized)) != null;
  }

  String _stripDirectionMarks(String value) {
    return value
        .replaceAll('\u2066', '')
        .replaceAll('\u2067', '')
        .replaceAll('\u2068', '')
        .replaceAll('\u2069', '')
        .replaceAll('\u200E', '')
        .replaceAll('\u200F', '')
        .trim();
  }

  double _measureMoney(
    String value, {
    required double size,
    required bool bold,
  }) {
    final amountPainter = _plainPainter(
      amount(value),
      size: size,
      bold: bold,
      fontFamily: 'monospace',
    )..layout();

    final symbolPainter = _plainPainter(
      _riyalSymbol,
      size: size,
      bold: bold,
      fontFamily: _riyalFontFamily,
    )..layout();

    return amountPainter.height > symbolPainter.height
        ? amountPainter.height
        : symbolPainter.height;
  }

  void _drawMoney(
    Canvas canvas,
    String value,
    Rect rect, {
    required double size,
    required bool bold,
    required TextAlign align,
  }) {
    final amountText = amount(value);
    final gap = size * 0.18;

    final amountPainter = _plainPainter(
      amountText,
      size: size,
      bold: bold,
      fontFamily: 'monospace',
    )..layout();

    final symbolPainter = _plainPainter(
      _riyalSymbol,
      size: size,
      bold: bold,
      fontFamily: _riyalFontFamily,
    )..layout();

    final totalWidth = symbolPainter.width + gap + amountPainter.width;
    final totalHeight = amountPainter.height > symbolPainter.height
        ? amountPainter.height
        : symbolPainter.height;

    final x = _dxFor(rect, totalWidth, align);
    final y =
        rect.top + ((rect.height - totalHeight) / 2).clamp(0.0, rect.height);

    // In RTL visual layout:
    // amount stays on the right, currency symbol stays after it on the left.
    final symbolX = x;
    final amountX = x + symbolPainter.width + gap;

    symbolPainter.paint(
      canvas,
      Offset(symbolX, y + ((amountPainter.height - symbolPainter.height) / 2)),
    );

    amountPainter.paint(canvas, Offset(amountX, y));
  }

  TextPainter _plainPainter(
    String value, {
    required double size,
    required bool bold,
    required String fontFamily,
  }) {
    return TextPainter(
      text: TextSpan(
        text: value,
        style: TextStyle(
          color: Colors.black,
          fontSize: size,
          fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
          height: 1.08,
          fontFamily: fontFamily,
        ),
      ),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.left,
      textWidthBasis: TextWidthBasis.longestLine,
    );
  }

  double _dxFor(Rect rect, double width, TextAlign align) {
    if (align == TextAlign.right || align == TextAlign.end) {
      return rect.right - width;
    }

    if (align == TextAlign.center || align == TextAlign.justify) {
      return rect.left + ((rect.width - width) / 2);
    }

    return rect.left;
  }

  TextPainter _painter(
    String value, {
    required double size,
    required bool bold,
    required TextAlign align,
    required TextDirection dir,
    required int? maxLines,
  }) {
    final normalized = value
        .replaceAll('ر.س.', _riyalSymbol)
        .replaceAll('ر.س', _riyalSymbol)
        .replaceAll('SAR', _riyalSymbol)
        .replaceAll('sar', _riyalSymbol);

    return TextPainter(
      text: TextSpan(
        text: normalized,
        style: TextStyle(
          color: Colors.black,
          fontSize: size,
          fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
          height: 1.08,
          fontFamily: _plainFontFamily(normalized),
          fontFamilyFallback: const [_riyalFontFamily],
        ),
      ),
      maxLines: maxLines,
      textAlign: align,
      textDirection: dir,
      textWidthBasis: TextWidthBasis.longestLine,
      ellipsis: maxLines == null ? null : '…',
    );
  }

  String? _plainFontFamily(String value) {
    if (_hasArabic(value)) return null;
    return 'monospace';
  }

  bool _hasArabic(String value) => RegExp(r'[\u0600-\u06FF]').hasMatch(value);
}
